// HabitTracker.js
import React from 'react';

function HabitTracker() {
  return (
    <div>
      <h1 className="text-2xl font-bold">21-Day Habit Tracker</h1>
      {/* TODO: Add habit tracker UI here */}
    </div>
  );
}

export default HabitTracker;
