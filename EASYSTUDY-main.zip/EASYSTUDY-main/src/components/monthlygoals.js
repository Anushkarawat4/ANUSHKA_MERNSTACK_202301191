// MonthlyReminders.js
import React from 'react';

function MonthlyReminders() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Monthly Reminders</h1>
      {/* TODO: Add reminders UI here */}
    </div>
  );
}

export default MonthlyReminders;
